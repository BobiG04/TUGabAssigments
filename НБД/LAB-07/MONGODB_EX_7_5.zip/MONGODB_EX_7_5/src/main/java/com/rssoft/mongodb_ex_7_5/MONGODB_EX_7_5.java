package com.rssoft.mongodb_ex_7_5;

import com.mongodb.MongoClient;
import com.mongodb.client.MapReduceIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;
import org.json.JSONException;
import org.json.JSONObject;

public class MONGODB_EX_7_5 {
    public static void main(String[] args) {

        final String DATABASE_NAME = "my-sensors";
        final String COLLECTION_NAME = "data";
        final String SENSOR_TYPE = "temperature";
        final int VALUE_TH = 20;
        
        String mapFunction = 
                    "function(){ "
                        + "if (this.type === \""+ SENSOR_TYPE +"\") {"
                            + "if (this.value > "+ VALUE_TH +") {"
                                + "emit(this.type, this.value)"
                            + "}"
                        + "}"    
                    + "}";
       
        String reduceFunction = 
                    "function(type, value){"
                        + "var n = value.length;"
                        + "var sum = 0;"
                        + "for (var i=0; i<n;i++) {"
                            + "sum += value[i];"
                        + "}"
                        + "return sum/n;"
                    + "}";

        try {
            // ----------------------------------------------- Connect to server
            MongoClient mongoClient = new MongoClient("localhost", 27017);
            //-------------------------------------------------- Create database
            MongoDatabase db = mongoClient.getDatabase(DATABASE_NAME);
            //------------------------------------------------ Create collection
            MongoCollection<Document> collection
                    = db.getCollection(COLLECTION_NAME);
            // ------------------------------------------------------ Map-Reduce
            MapReduceIterable<Document> result = collection
                    .mapReduce(mapFunction, reduceFunction);
            // ----------------------------------------------------- Show result
            MongoCursor<Document> iterator = result.iterator();
            while (iterator.hasNext()) {
                Document document = iterator.next();
                String json = document.toJson();
                JSONObject obj = new JSONObject(json);
                String sensorType = obj.getString("_id");
                String unit = sensorType.equals("temperature") ? "\u00B0C" : "%";
                double val = obj.getDouble("value");
                System.out.printf("Average %s: %.2f%s\n", sensorType, val, unit);
            }
            // -----------------------------------------------------------------
            
        } catch (JSONException e) {
            System.out.println(e);
        }
    }

}
