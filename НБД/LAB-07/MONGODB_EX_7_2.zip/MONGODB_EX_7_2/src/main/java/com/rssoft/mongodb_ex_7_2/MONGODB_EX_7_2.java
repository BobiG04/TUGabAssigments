
package com.rssoft.mongodb_ex_7_2;

import com.mongodb.MongoClient;
import com.mongodb.client.MapReduceIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import static com.mongodb.client.model.Filters.lt;
import java.time.Instant;
import java.util.Date;
import org.bson.Document;
import org.bson.conversions.Bson;
import org.json.JSONException;
import org.json.JSONObject;

public class MONGODB_EX_7_2 {
    public static void main(String[] args) {

        final String DATABASE_NAME = "my-sensors";
        final String COLLECTION_NAME = "data";
        final String KEY = "type";
        final String VALUE = "value";
        
        String mapFunction = 
                String.format("function() {emit(this.%s, this.%s)}", 
                        KEY, VALUE);
        String reduceFunction = 
                String.format("function(%s, %s) {return Array.avg(%s);}", 
                       KEY, VALUE, VALUE);
        
        String date = "2021-06-20T00:00:00.000Z";
        Instant instant = Instant.parse(date);
        Date timestamp = Date.from(instant);
        Bson query = lt("timestamp", timestamp);
           
        try {
            // ----------------------------------------------- Connect to server
            MongoClient mongoClient = new MongoClient("localhost", 27017);
            //-------------------------------------------------- Create database
            MongoDatabase db = mongoClient.getDatabase(DATABASE_NAME);
            //------------------------------------------------ Create collection
            MongoCollection<Document> collection
                    = db.getCollection(COLLECTION_NAME);
            // ------------------------------------------------------ Map-Reduce
            MapReduceIterable<Document> result = collection
                    .mapReduce(mapFunction, reduceFunction)
                    .filter(query);
            // ----------------------------------------------------- Show result
            MongoCursor<Document> iterator = result.iterator();
            while (iterator.hasNext()) {
                Document document = iterator.next();
                String json = document.toJson();
                JSONObject obj = new JSONObject(json);
                String sensorType = obj.getString("_id");
                String unit = sensorType.equals("temperature") ? "\u00B0C" : "%";
                double val = obj.getDouble("value");
                System.out.printf("Average %s: %.2f%s\n", sensorType, val, unit);
            }
            // -----------------------------------------------------------------
            
        } catch (JSONException e) {
            System.out.println(e);
        }
    }

}
