
$(function () {
    $("#submit").click(function() {
        sendQuery();
    });
    $('[data-position="info-box"]').click(function() {
        view('query-box');
    });
    $(document).on({
        ajaxStart: function () {
            view('loading-box');
        },
        ajaxStop: function () {
            hide('loading-box');
        }
    });
    view('query-box');
});


