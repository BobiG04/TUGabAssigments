
var PORT = 443;
var TIMEOUT = 4000;
var PROTOCOL = 'https://';
var SERVER_NAME =
 'dc3b328b-545c-4c02-9457-531fdc110a3e-bluemix.cloudantnosqldb.appdomain.cloud';
var DATABASE = 'students2';  
var KEY = 'apikey-fe27795948f14d4fb4c463eff484fb35';
var PASSWORD = '6aed1b959f1091ae9b824613590aeeda08398b6f';
// 
// -----------------------------------------------------------------------------
function addResultToPage(result) {
    var resAsString = JSON.stringify(result);
    showInfo(resAsString);
}
// -----------------------------------------------------------------------------
function sendQuery() {
    var hash = btoa(KEY + ':' + PASSWORD);
    getResult(hash)
        .then(function (result) {
            addResultToPage(result);
        }).catch(
            function (error) {
                var status = error.status;
                if (status === 0) {
                    showError('Невъзможна е връзката с базата данни!', 3);
                }
                else if (status === 401) {
                    showError('Грешка при авторизация!', 3);
                }
                else {
                    showError('Грешен синтаксис на заявката!', 3);
                }
            }
    );
}
// -----------------------------------------------------------------------------
function getResult(hash) {   
    var url = PROTOCOL + SERVER_NAME + '/' + DATABASE + '/_find'; 
    var query = $("textarea").val();
    if (query === '') {
        showError('Моля, въведете вашата Mango заявка!', 3);
        return;
    }  
    var promise = new Promise(function (resolve, reject) {
        $.ajax({
            type: "POST",
            url: url,
            cache: false,
            contentType: "application/json",
            dataType: "json",
            data: query,
            timeout: TIMEOUT,
            beforeSend: function (req) {
                req.setRequestHeader('Accept', 'application/json');
                req.setRequestHeader('Authorization', 'Basic ' + hash);
            },
            success: function (data) {
                resolve(data);
            },
            error: function (data) {
                reject(data);
            }
        });
    });
    return promise;
}
// -----------------------------------------------------------------------------