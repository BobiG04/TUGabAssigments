/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mongodb_ex_5_1;

import static com.mongodb.client.model.Filters.and;
import static com.mongodb.client.model.Filters.eq;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.conversions.Bson;
import org.bson.Document;
import org.json.JSONObject;

public class MONGODB_EX_5_1 {
    public static void main(String[] args) {
        Bson filter = eq("grade.value", 2L);
        Bson project = and(eq("_id", 0L), eq("name", 1L));
        Bson sort = eq("name", 1L);

        MongoClient mongoClient = new MongoClient(
                new MongoClientURI(
                        "mongodb://localhost:27017"
                )
        );
        MongoDatabase database = mongoClient.getDatabase("students");
        MongoCollection<Document> collection = database.getCollection("data1");
        FindIterable<Document> result = collection.find(filter)
                .projection(project)
                .sort(sort);
        
        for (Document document : result) {
            String json = document.toJson();
            JSONObject obj = new JSONObject(json);
            JSONObject nameObj = obj.getJSONObject("name");
            String firstName = nameObj.getString("firstName");
            String lastName = nameObj.getString("lastName");
            System.out.printf("%s %s\n", firstName, lastName);
        }
        
    }

}
