package mongodb_ex_5_3;

import java.util.Arrays;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.client.AggregateIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import java.util.Iterator;
import org.bson.Document;
import org.json.JSONArray;
import org.json.JSONObject;

public class MONGODB_EX_5_3 {

    final static long GRADE = 4;
    
    public static void main(String[] args) {
        
        MongoClient mongoClient = new MongoClient(
                new MongoClientURI(
                        "mongodb://localhost:27017"
                )
        );
        MongoDatabase database = mongoClient.getDatabase("students");
        MongoCollection<Document> collection = database.getCollection("data1");

        AggregateIterable<Document> result
                = collection.aggregate(Arrays.asList(
                    new Document("$match",
                        new Document("grade",
                            new Document("$elemMatch",
                                new Document("value", GRADE)))),
                    new Document("$unwind",
                        new Document("path", "$grade")),
                    new Document("$match",
                        new Document("grade.value", GRADE)),
                    new Document("$group",
                        new Document("_id", "$name")
                            .append("grades",
                                new Document("$addToSet", "$grade")))));

        for (Document document : result) {
            String json = document.toJson();
            JSONObject obj = new JSONObject(json);
            JSONObject nameObj = obj.getJSONObject("_id");

            String firstName = nameObj.getString("firstName");
            String lastName = nameObj.getString("lastName");
            System.out.printf("\n%s %s: ", firstName, lastName);

            JSONArray gradeObj = obj.getJSONArray("grades");
            Iterator<Object> iterator = gradeObj.iterator();
            while (iterator.hasNext()) {
                JSONObject itemObj = (JSONObject)iterator.next();
                String subject = itemObj.getString("subject");
                System.out.printf("%s ", subject);
            }
        }
        System.out.println("");
       
    }

}


