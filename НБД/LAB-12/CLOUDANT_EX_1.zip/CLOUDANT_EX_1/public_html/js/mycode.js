
$(function () {
    $("#submit").click(function() {
        sendQuery();
    });
    $(document).on({
        ajaxStart: function () {
            view('loading-box');
        },
        ajaxStop: function () {
            hide('loading-box');
        }
    });
    view('query-box');
});


