/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

var PORT = 443;
var TIMEOUT = 4000;
var PROTOCOL = 'https://';
var SERVER_NAME =
 'dc3b328b-545c-4c02-9457-531fdc110a3e-bluemix.cloudantnosqldb.appdomain.cloud';
var DATABASE = 'students';
var DOCUMENT = '_all_docs'; // 'student-0001'; 
var RES_PARS = '?include_docs=true';  
var KEY = 'apikey-a13473867922429ea5571840ae260342';
var PASSWORD = '53a874f75d9825ff9aa9c10d3c6ace4449da2045';
// 
// -----------------------------------------------------------------------------
function addResultToPage(result) {
    var id = result.id;
    var firstName = result.name.firstName;
    var lastName = result.name.lastName;
    var name = `${firstName} ${lastName} - ${id}`;
    var divName = '<div id="info-name">' + name + '</div>';

    var grades = result.grade;
    var gradesHtmlStart = '<ul class="grades">';
    var gradesHtmlEnd = '</ul>';
    var gradesHtml = gradesHtmlStart;
    grades.forEach(function (grade) {
        var subject = grade.subject;
        var value = grade.value;
        var pair = `${subject}: ${value}`;
        gradesHtml += `<li class="grades">${pair}</li>`;                   
    });
    gradesHtml += gradesHtmlEnd;
    var divGrades = '<div id="info-grades">' + gradesHtml + '</div>';
    showInfo(divName + divGrades);

}
// -----------------------------------------------------------------------------
function sendQuery() {
    var hash = btoa(KEY + ':' + PASSWORD);
    getResult(hash)
        .then(function (result) {
            var n = Object.keys(result).length;
            if (n === 1) {
                addResultToPage(result);
            }
            else {
                var rows = result.rows;
                rows.forEach(function(row) {
                    addResultToPage(row.doc);
                });
            }
        }).catch(
            function (error) {
                var status = error.status;
                if (status === 0) {
                    showError('Невъзможна е връзката с базата данни!', 3);
                }
                else if (status === 401) {
                    showError('Грешка при авторизация!', 3);
                }
            }
    );
}
// -----------------------------------------------------------------------------
function getResult(hash) {
    var url = PROTOCOL + SERVER_NAME + ':' + PORT + '/' + DATABASE + '/' +
            DOCUMENT + RES_PARS;
    var promise = new Promise(function (resolve, reject) {
        $.ajax({
            type: 'GET',
            url: url,
            async: true,
            cache: false,
            contentType: 'application/json',
            timeout: TIMEOUT,
            beforeSend: function (req) {
                req.setRequestHeader('Accept', 'application/json');
                req.setRequestHeader('Authorization', 'Basic ' + hash);
            },
            success: function (data) {
                resolve(data);
            },
            error: function (data) {
                reject(data);
            }
        });
    });
    return promise;
}
// -----------------------------------------------------------------------------