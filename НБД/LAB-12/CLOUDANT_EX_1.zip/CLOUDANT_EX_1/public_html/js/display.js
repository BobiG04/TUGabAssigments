
function view(viewName) {
    $('main > section').hide();
    $(`[data-position=${viewName}]`).show();
}
function hide(viewName) {
    $(`[data-position=${viewName}`).hide();
}
function showInfo(data) {
    $('[data-position=info-box]').append(data);
    view('info-box');
}
function showError(errorMsg, time) {
    var errorBox = $('#error-info');
    errorBox.text(errorMsg);
    view('error-box');
    setTimeout(function () {
        $('[data-position=error-box]').fadeOut();
        view('query-box');
    }, time*1000);
}



