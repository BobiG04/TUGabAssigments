package com.rssoft.mongodb_ex_6_1;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import org.bson.Document;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


public class MONGODB_EX_6_1 {
    
    public static void main(String[] args) {
        
        final String DATABASE_NAME = "my-sensors";
        final String COLLECTION_NAME = "data";
        final String ARRAY_NAME = "data";
        final String FILE_NAME = "sensor-data.json";       
        String fpath = "src\\main\\java\\com\\rssoft\\mongodb_ex_6_1\\"+FILE_NAME;
        try {
            // --------------------------------------------- Read the whole file
            String content = new String(Files.readAllBytes(Paths.get(fpath)), 
                                                StandardCharsets.UTF_8);
            // ---------------------------------- Convert content to JSON object 
            JSONObject obj = new JSONObject(content);
            JSONArray data = obj.getJSONArray(ARRAY_NAME);
            // ----------------------------------------------- Connect to server
            MongoClient mongoClient = new MongoClient("localhost", 27017);
            //-------------------------------------------------- Create database
            MongoDatabase db = mongoClient.getDatabase(DATABASE_NAME);
            //------------------------------------------------ Create collection
            MongoCollection<Document> collection = 
                                            db.getCollection(COLLECTION_NAME);
            // ------------------------------- Write docs to selected collection
            int n = data.length();
            for (int i = 0; i < n; i++) {
                String dataAsString = 
                        data.getJSONObject(i).toString();
                Document doc = Document.parse(dataAsString);
                collection.insertOne(doc);
            }
            System.out.println("OK, " + n + " documents are added.");
            // -----------------------------------------------------------------
        } catch (IOException | JSONException e) {
            System.out.println(e);
        }
    }
    
}
