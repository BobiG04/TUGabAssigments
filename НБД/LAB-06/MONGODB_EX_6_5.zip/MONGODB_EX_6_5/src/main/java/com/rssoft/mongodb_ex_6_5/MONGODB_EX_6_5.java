
package com.rssoft.mongodb_ex_6_5;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import static com.mongodb.client.model.Filters.and;
import static com.mongodb.client.model.Filters.eq;
import static com.mongodb.client.model.Filters.lt;
import static com.mongodb.client.model.Updates.inc;
import org.bson.Document;
import org.bson.conversions.Bson;
import org.json.JSONException;

public class MONGODB_EX_6_5 {

    public static void main(String[] args) {

        final String DATABASE_NAME = "students";
        final String COLLECTION_NAME = "data1";
        final String SUBJECT_NAME = "НБД";

        try {
            // ----------------------------------------------- Connect to server
            MongoClient mongoClient = new MongoClient("localhost", 27017);
            //-------------------------------------------------- Create database
            MongoDatabase db = mongoClient.getDatabase(DATABASE_NAME);
            //------------------------------------------------ Create collection
            MongoCollection<Document> collection
                    = db.getCollection(COLLECTION_NAME);
            // ---------------------------------------------------- Update field
            Bson query = and(eq("grade.subject", SUBJECT_NAME),lt("grade.value",6));
            Bson update = inc("grade.$.value",1);
            collection.updateMany(query, update);
            
            System.out.println("Document update successfully...");
            // -----------------------------------------------------------------

        } catch (JSONException e) {
            System.out.println(e);
        }

    }
}
