
package com.rssoft.mongodb_ex_6_4;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import static com.mongodb.client.model.Filters.eq;
import static com.mongodb.client.model.Updates.set;
import org.bson.Document;
import org.bson.conversions.Bson;
import org.json.JSONException;

public class MONGODB_EX_6_4 {

    public static void main(String[] args) {

        final String DATABASE_NAME = "students";
        final String COLLECTION_NAME = "data1";
        final String SUBJECT_NAME = "НБД";
        final int GRADE = 5;

        try {
            // ----------------------------------------------- Connect to server
            MongoClient mongoClient = new MongoClient("localhost", 27017);
            //-------------------------------------------------- Create database
            MongoDatabase db = mongoClient.getDatabase(DATABASE_NAME);
            //------------------------------------------------ Create collection
            MongoCollection<Document> collection
                    = db.getCollection(COLLECTION_NAME);
            // ---------------------------------------------------- Update field
            
            Bson query = eq("grade.subject", SUBJECT_NAME);
            Bson update = set("grade.$.value", GRADE);
            collection.updateMany(query, update);
                    
            System.out.println("Document update successfully...");
            // -----------------------------------------------------------------

        } catch (JSONException e) {
            System.out.println(e);
        }

    }
}
