
package com.rssoft.mongodb_ex_6_6;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import static com.mongodb.client.model.Filters.gt;
import java.time.Instant;
import java.util.Date;
import org.bson.Document;
import org.bson.conversions.Bson;
import org.json.JSONException;

public class MONGODB_EX_6_6 {

    public static void main(String[] args) {

        final String DATABASE_NAME = "my-sensors";
        final String COLLECTION_NAME = "data";

        try {
            // ----------------------------------------------- Connect to server
            MongoClient mongoClient = new MongoClient("localhost", 27017);
            //-------------------------------------------------- Create database
            MongoDatabase db = mongoClient.getDatabase(DATABASE_NAME);
            //------------------------------------------------ Create collection
            MongoCollection<Document> collection
                    = db.getCollection(COLLECTION_NAME);
            // ---------------------------------------------------- Update field
            Instant instant = Instant.parse("2021-06-20T00:00:00.000Z"); 
            Date timestamp = Date.from(instant);
            Bson query = gt("timestamp", timestamp);
            collection.deleteMany(query);
            
            System.out.println("Document update successfully...");
            // -----------------------------------------------------------------

        } catch (JSONException e) {
            System.out.println(e);
        }

    }
}
