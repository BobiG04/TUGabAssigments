package com.mycompany.pis_sem_upr;

public class PIS_Sem_Upr {

    public static void main(String[] args) {
        
        for(int i=4; i<21; i++) {
            if (i%2 == 0) {
                System.out.println(i);
            }
        }
        
    }
    
}
