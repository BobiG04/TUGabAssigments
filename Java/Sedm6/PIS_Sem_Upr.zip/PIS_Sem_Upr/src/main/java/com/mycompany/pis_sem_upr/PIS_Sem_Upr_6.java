package com.mycompany.pis_sem_upr;

public class PIS_Sem_Upr_6 {
    public static void main (String[] args) {
        
        int[] arr = new int[20];
        
        for (int i=0; i<arr.length; i++) {
            
            arr[i] = i * 5;
            System.out.println(arr[i]);
            
        }
        
    }
}
