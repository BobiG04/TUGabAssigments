package com.mycompany.pis_sem_upr;

public class PIS_Sem_Upr_2 {
    public static void main (String[] args) {
    
        for (int i = 50; i > 7; i--) {
        
            if (i%2 == 1)
                System.out.println(i);
            
        }
        
    }
    
}
