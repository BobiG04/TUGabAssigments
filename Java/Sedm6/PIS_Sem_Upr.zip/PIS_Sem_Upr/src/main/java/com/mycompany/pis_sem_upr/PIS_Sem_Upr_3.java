package com.mycompany.pis_sem_upr;

public class PIS_Sem_Upr_3 {
    
    public static void main(String[] args) {
        
        for(int i=3; i<28; i++) {
            
            System.out.println(i);
            
        }
        
    }
    
}
