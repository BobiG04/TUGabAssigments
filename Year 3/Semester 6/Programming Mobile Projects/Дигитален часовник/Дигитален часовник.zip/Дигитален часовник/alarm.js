// filepath: d:\GitHub\TUGabAssigments\ПМП\Дигитален часовник\alarm.js
/* Vanilla JS alarm clock compatible with mobile and Monaca */
(function () {
    'use strict';

    let alarmTime = null;
    let alarmActive = false;
    let alarmRinging = false;
    const audio = new Audio('./src/alarmSounds/iphone_alarm.mp3');

    function pad2(n) { return String(n).padStart(2, '0'); }

    function updateTime() {
        const now = new Date();
        const hours = pad2(now.getHours());
        const minutes = pad2(now.getMinutes());
        const seconds = pad2(now.getSeconds());

        const timeEl = document.getElementById('current-time');
        if (timeEl) timeEl.textContent = `${hours}:${minutes}:${seconds}`;

        if (alarmActive && alarmTime && !alarmRinging) {
            const currentHM = `${hours}:${minutes}`;
            if (currentHM === alarmTime) {
                triggerAlarm();
            }
        }
    }

    function showStatus(text, isError) {
        const status = document.getElementById('alarm-status');
        if (status) {
            status.textContent = text;
            status.className = isError ? 'status error' : 'status';
        } else {
            alert(text);
        }
    }

    window.setAlarm = function () {
        const inputEl = document.getElementById('alarm-time');
        if (!inputEl) return showStatus('Поле за аларма липсва', true);

        const input = inputEl.value; // format 'HH:MM'
        if (!input) return showStatus('Моля, въведи време', true);

        // input type=time returns 'HH:MM' (24h); accept that directly
        if (!/^\d{2}:\d{2}$/.test(input)) return showStatus('Невалиден формат (HH:MM)', true);

        alarmTime = input;
        alarmActive = true;
        showStatus(`Аларма зададена за ${alarmTime}`);
        // Load audio so it can play on trigger (user gesture already occurred)
        audio.load();
    };

    window.cancelAlarm = function () {
        alarmActive = false;
        alarmTime = null;
        if (alarmRinging) stopAlarm();
        showStatus('Алармата е отменена');
    };

    function triggerAlarm() {
        alarmRinging = true;
        alarmActive = false;

        // Try play audio; if blocked, fallback to WebAudio beep
        audio.play().catch(() => fallbackBeep());

        // Vibrate if available
        if (typeof navigator !== 'undefined' && navigator.vibrate) {
            try { navigator.vibrate([500,200,500,200,500]); } catch (e) {}
        }

        showStatus('⏰ АЛАРМА! Натисни Стоп за да спреш', false);

        // show stop UI if present
        const stopBtn = document.getElementById('stop-alarm');
        if (stopBtn) stopBtn.style.display = 'inline-block';
    }

    function stopAlarm() {
        alarmRinging = false;
        try { audio.pause(); audio.currentTime = 0; } catch (e) {}
        if (typeof navigator !== 'undefined' && navigator.vibrate) {
            try { navigator.vibrate(0); } catch (e) {}
        }
        showStatus('Алармата е спряна');
        const stopBtn = document.getElementById('stop-alarm');
        if (stopBtn) stopBtn.style.display = 'none';
    }

    function fallbackBeep() {
        try {
            const ctx = new (window.AudioContext || window.webkitAudioContext)();
            const o = ctx.createOscillator();
            const g = ctx.createGain();
            o.type = 'sine';
            o.frequency.value = 880;
            g.gain.value = 0.1;
            o.connect(g);
            g.connect(ctx.destination);
            o.start();
            setTimeout(() => { o.stop(); try { ctx.close(); } catch (e) {} }, 2000);
        } catch (e) {}
    }

    // wire up buttons after DOM ready
    document.addEventListener('DOMContentLoaded', function () {
        const setBtn = document.getElementById('set-alarm');
        const cancelBtn = document.getElementById('cancel-alarm');
        const stopBtn = document.getElementById('stop-alarm');

        if (setBtn) setBtn.addEventListener('click', setAlarm);
        if (cancelBtn) cancelBtn.addEventListener('click', cancelAlarm);
        if (stopBtn) stopBtn.addEventListener('click', stopAlarm);

        // For Cordova/Monaca, wait for deviceready if available
        function ready() {
            updateTime();
            setInterval(updateTime, 1000);
        }

        if (window.cordova) {
            document.addEventListener('deviceready', ready, false);
        } else {
            ready();
        }
    });
})();